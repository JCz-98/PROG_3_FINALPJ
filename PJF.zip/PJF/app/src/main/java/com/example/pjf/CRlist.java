package com.example.pjf;

import java.util.ArrayList;

public class CRlist
{
    private static volatile CRlist instance = null;

    protected ArrayList<String> CR_LIST;
    protected ArrayList<String> R_LIST;
    protected ArrayList<String> C_LIST;


    private CRlist()
    {
        CR_LIST = new ArrayList<>();
        R_LIST = new ArrayList<>();
        C_LIST = new ArrayList<>();
    }

    public static CRlist getInstance()
    {
        if (instance == null) {
            synchronized(CRlist.class)
            {
                if (instance == null) {
                    instance = new CRlist();
                }
            }
        }

        return instance;
    }

    public ArrayList<String> getCR_LIST()
    {
        return CR_LIST;
    }
    public ArrayList<String> getR_LIST()
    {
        return R_LIST;
    }
    public ArrayList<String> getC_LIST()
    {
        return C_LIST;
    }

}
