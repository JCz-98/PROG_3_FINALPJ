package com.example.pjf;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;


public class CWebpageActivityFragment extends Fragment
{
    public static WebView webView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {

        String title = (String) getActivity().getTitle();

        Log.v("ONCREATE WEBFRAGMENT", "O!NNNNN");

        super.onCreateView(inflater, container, savedInstanceState);

        View view = inflater.inflate(R.layout.fragment_cwebpage_activity, container, false);
        webView = view.findViewById(R.id.cwebview);


        Intent intent = getActivity().getIntent();

        String cname = intent.getStringExtra("cname");

        if(cname != null)
        {
            String newtitle = title + ": " + cname;
            getActivity().setTitle(newtitle);
        }

        loadCountryWebPage(cname);

        return view; // return the fragment's view for display
    }

    public static void loadCountryWebPage(String cname)
    {
        //String newtitle = "Countries WebPage";
        if(cname == null)
        {
            String URL = "https://en.wikipedia.org";
            webView.setWebViewClient(new WebViewClient());
            webView.loadUrl(URL);
        }
        else
        {
            String URL = "https://en.wikipedia.org/wiki/" + cname;

            webView.setWebViewClient(new WebViewClient());
            webView.loadUrl(URL);
        }

    }
}
