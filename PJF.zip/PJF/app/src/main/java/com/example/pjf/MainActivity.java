// PROYECTO FINAL
// JONATHAN CAZCO, ERICK ÑAUÑAY

// REFERENCIAS (modeled and modified after):
// FlagQuizz App --> Deitel
// https://www.youtube.com/watch?v=fGcMLu1GJEc --> coding in flow
// https://www.youtube.com/watch?v=TUXui5ItBkM --> coding in flow
// https://ptyagicodecamp.github.io/adding-menu-items-in-navigation-drawer-dynamically.html
// https://www.youtube.com/watch?v=S7U2rZ83tWM

package com.example.pjf;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

import java.util.Set;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener

{
    // keys for reading data from SharedPreferences
    public static final String REGIONS = "pref_regionsToInclude";
    public static String DEFREGION = "South_America";

    private boolean phoneDevice = true; // used to force portrait mode
    private boolean preferencesChanged = true; // did preferences change?

    private DrawerLayout drawer;
    protected static CRlist cr_list = CRlist.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cr_list = CRlist.getInstance();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);

        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        drawer.addDrawerListener(toggle);
        toggle.syncState();


        //from FlagQuiz

        // set default values in the app's SharedPreferences
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false);

        // register listener for SharedPreferences changes
        PreferenceManager.getDefaultSharedPreferences(this).
                registerOnSharedPreferenceChangeListener(preferencesChangeListener);

        // determine screen size
        int screenSize = getResources().getConfiguration().screenLayout &
                Configuration.SCREENLAYOUT_SIZE_MASK;

        // if device is a tablet, set phoneDevice to false
        if (screenSize == Configuration.SCREENLAYOUT_SIZE_LARGE ||
                screenSize == Configuration.SCREENLAYOUT_SIZE_XLARGE)
            phoneDevice = false; // not a phone-sized device

        // if running on phone-sized device, allow only portrait orientation
        if (phoneDevice)
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

    }



    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem)
    {

        String sel_region = String.valueOf(menuItem.getTitle());
        String title = "Countries Webpage || " + sel_region;
        setTitle(title);

        if(sel_region.contains("North"))
        {
            sel_region = "North_America";
        }
        else if(sel_region.contains("South"))
            sel_region = "South_America";

        MainActivityFragment CRFragment = (MainActivityFragment)
                getSupportFragmentManager().findFragmentById(R.id.quizFragment);

        CRFragment.createFlagNCountry_forListView(sel_region);

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed()
    {
        if(drawer.isDrawerOpen(GravityCompat.START))
        {
            drawer.closeDrawer(GravityCompat.START);
        }
        else
        {
            super.onBackPressed();
        }
    }

    public void addMenuItemInNavMenuDrawer()
    {
        NavigationView navView = (NavigationView) findViewById(R.id.nav_view);
        Menu menu = navView.getMenu();

        for(String key: cr_list.R_LIST)
        {
            Log.i("IN SINGLETON REGION: ", key);
            menu.add(key).setIcon(R.drawable.ic_chevron_right_black_24dp);
        }

        navView.invalidate();
    }

    //from FlagQuizz

    // called after onCreate completes execution
    @Override
    protected void onStart()
    {
        super.onStart();

        if (preferencesChanged)
        {
            // now that the default preferences have been set,
            // initialize MainActivityFragment and start the app
            MainActivityFragment quizFragment = (MainActivityFragment)
                    getSupportFragmentManager().findFragmentById(R.id.quizFragment);

            quizFragment.updateRegions(PreferenceManager.getDefaultSharedPreferences(this));
            addMenuItemInNavMenuDrawer();
            quizFragment.fillCountryLists();

            if(cr_list.R_LIST.size() == 1)
            {
                if(cr_list.R_LIST.get(0).contains("North"))
                {
                    DEFREGION = "North_America";
                }
                else if(cr_list.R_LIST.get(0).contains("South"))
                    DEFREGION = "South_America";

                else
                    {
                    DEFREGION = cr_list.R_LIST.get(0);
                }
            }
            else
            {
                for(String key:cr_list.R_LIST)
                {
                    if(!key.contains("South"))
                    {
                        if(key.contains("North"))
                        {
                            DEFREGION = "North_America";
                            break;
                        }
                        else
                        {
                            DEFREGION = cr_list.R_LIST.get(0);
                            break;
                        }
                    }
                }
            }
            String title = "Countries Webpage || " + cr_list.R_LIST.get(0);
            setTitle(title);

            quizFragment.createFlagNCountry_forListView(DEFREGION);
            preferencesChanged = false;
        }
    }

    // show menu if app is running on a phone or a portrait-oriented tablet
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
            getMenuInflater().inflate(R.menu.menu_main, menu);
            return true;
    }

    // displays the SettingsActivity when running on a phone
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        Intent preferencesIntent = new Intent(this, SettingsActivity.class);
        startActivity(preferencesIntent);
        return super.onOptionsItemSelected(item);
    }

    // listener for changes to the app's SharedPreferences
    private OnSharedPreferenceChangeListener preferencesChangeListener =
            new OnSharedPreferenceChangeListener()
            {
                // called when the user changes the app's preferences
                @Override
                public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key)
                {
                    preferencesChanged = true; // user changed app setting

                    if (key.equals(REGIONS))
                    { // regions to include changed
                        Set<String> regions = sharedPreferences.getStringSet(REGIONS, null);

                        if (regions != null && regions.size() > 0)
                        {
                            //quizFragment.updateRegions(sharedPreferences);
                            Log.i("INFO:", "VALIDA REGIONS");
                            //quizFragment.resetQuiz();
                        }
                        else
                            {
                            // must select one region--set North America as default
                            SharedPreferences.Editor editor =
                                    sharedPreferences.edit();
                            regions.add(getString(R.string.default_region));
                            editor.putStringSet(REGIONS, regions);
                            editor.apply();

                            Toast.makeText(MainActivity.this, R.string.default_region_message,
                                    Toast.LENGTH_LONG).show();
                            Log.i("INFO:", "VALIDA AL MENOS UNO");
                            return;
                        }
                    }

                    Toast.makeText(MainActivity.this, R.string.restarting_quiz, Toast.LENGTH_SHORT).show();
                }
            };

}
