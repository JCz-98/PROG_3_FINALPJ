// MainActivityFragment.java
// Contains the Flag Quiz logic
package com.example.pjf;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public class MainActivityFragment extends Fragment
{
    protected static CRlist cr_list = CRlist.getInstance();


    private ListView cList;


    private static List<String> fileNameList = new ArrayList<>(); // flag file names
    private static List<String> CountriesList = new ArrayList<>(); // countries in app

    private Set<String> regionsSet; // world regions in singleton

    // configures the MainActivityFragment when its View is created
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_clist, container, false);

        cList = view.findViewById(R.id.listview);

        Log.v("ONCREATE FRAGMENT", "ONNNNNN");


        cList.setOnItemClickListener(countrySelected);

        return view; // return the fragment's view for display
    }

    AdapterView.OnItemClickListener countrySelected = new AdapterView.OnItemClickListener()
    {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
        {

            TextView trial = view.findViewById(R.id.ftextView);

            String cname = trial.getText().toString();

            Intent intent = new Intent(getActivity().getApplicationContext(), CWebpageActivity.class);

            // determine screen size
            int screenSize = getResources().getConfiguration().screenLayout &
                    Configuration.SCREENLAYOUT_SIZE_MASK;

            // if device is a tablet, send only country name
            if (screenSize == Configuration.SCREENLAYOUT_SIZE_LARGE ||
                    screenSize == Configuration.SCREENLAYOUT_SIZE_XLARGE)
            {
                CWebpageActivityFragment.loadCountryWebPage(cname);
                String def_title = "Country WebPage: ";
                getActivity().setTitle(def_title + cname);
            }
            else
            {
                intent.putExtra("cname", cname);
                startActivity(intent);
            }


        }
    };


    class CListAdapter extends BaseAdapter
    {
        private List<String> cur_clist;
        private List<String> cur_flist;

        public CListAdapter(List<String> c, List<String> f)
        {
            this.cur_clist = new ArrayList<>(c);
            this.cur_flist = new ArrayList<>(f);
        }

        @Override
        public int getCount() {
            return cur_clist.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup)
        {

            View inview = getLayoutInflater().inflate(R.layout.country_listitem, null);

            TextView cname = inview.findViewById(R.id.ftextView);
            ImageView flag = inview.findViewById(R.id.flag_imageView);

            cname.setText(cur_clist.get(i));

            AssetManager assets = getActivity().getAssets();

            try (InputStream stream = assets.open(cur_flist.get(i))) {
                Drawable flag_img = Drawable.createFromStream(stream, cur_clist.get(i));
                flag.setImageDrawable(flag_img);

            } catch (IOException exception) {
                Log.e("TAG", "Error loading " + cur_clist.get(i), exception);
            }

            return inview;
        }
    }

    public void fillCountryLists()
    {

        AssetManager assets = getActivity().getAssets();
        cr_list.C_LIST.clear(); // empty list of image file names
        try {
            // loo through each region
            for (String region : cr_list.R_LIST) {

                if (region.contains("North")) {
                    region = "North_America";
                }

                if (region.contains("South"))
                    region = "South_America";

                String[] paths = assets.list(region);

                for (String path : paths) {
                    String name = path.replace(".png", "");
                    cr_list.C_LIST.add(name);
                    Log.v("FILLCOUNTRY: ", name);
                }
                //Log.v("CLIST LENGHT: ", String.valueOf(cr_list.C_LIST.size()));
            }
        } catch (IOException exception) {
            Log.e("TAG", "Error loading image file names", exception);
        }
    }

    // update world regions for quiz based on values in SharedPreferences
    public void updateRegions(SharedPreferences sharedPreferences) {
        regionsSet = sharedPreferences.getStringSet(MainActivity.REGIONS, null);
        cr_list.R_LIST = new ArrayList<String>(regionsSet);

        Collections.sort(cr_list.R_LIST);
    }

    public void createFlagNCountry_forListView(String region)
    {
        boolean in_assets = false;

        CountriesList.clear();
        fileNameList.clear();

        for (String R : cr_list.C_LIST) {

            if (R.contains(region)) {
                in_assets = true;
                String name = getCountryName(R);
                CountriesList.add(name);
                Log.v("COUNTRY NAME ARRAY", name);

                fileNameList.add(region + "/" + R + ".png");
            }

        }

        if (in_assets == false)
        {
            Toast.makeText(getContext(), "Region not found in Assets Dir", Toast.LENGTH_LONG).show();
        }

        Log.i("ARGUNEMTS:", "TO ADAPTER");
        CListAdapter adapter = new CListAdapter(CountriesList, fileNameList);

        cList.setAdapter(adapter);

    }

    // parses the country flag file name and returns the country name
    private String getCountryName(String name)
    {
        return name.substring(name.indexOf('-') + 1).replace('_', ' ');
    }

}

