package com.example.pjf;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CWebpageActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cwebpage);
    }
}
